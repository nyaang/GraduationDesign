#
import os

os.system('python main_py.py res/hin2vecdata_U_cleaned.txt node_vectors.txt metapath_vectors.txt -l 100 -d 100 -w 3')